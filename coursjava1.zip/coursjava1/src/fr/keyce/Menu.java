package fr.keyce;

import fr.keyce.openit.Computer;
import fr.keyce.openit.Keyboard;
import fr.keyce.openit.Mouse;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {

    private static List<Computer> computers = new ArrayList<>();

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n******** MENU ********");
                System.out.println("1. Afficher les ordinateurs");
                System.out.println("2. Changer le nom de l'ordinateur");
                System.out.println("3. Ajouter un ordinateur");
                System.out.println("4. Supprimer un ordinateur");
                System.out.println("5. Quitter");
                System.out.print("Choisissez une option : ");

                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        displayComputers();
                        break;
                    case 2:
                        changeComputerName(scanner);
                        break;
                    case 3:
                        addComputer(scanner);
                        break;
                    case 4:
                        deleteComputer(scanner);
                        break;
                    case 5:
                        System.out.println("AU REVOIR");
                        return;
                    default:
                        System.out.println("Option invalide, veuillez réessayer.");
                        break;
                }
            }
        }
    }

    private static void displayComputers() {
        if (computers.isEmpty()) {
            System.out.println("Aucun ordinateur n'est disponible.");
        } else {
            for (Computer computer : computers) {
                System.out.println(computer);
            }
        }
    }

    private static void changeComputerName(Scanner scanner) {
        System.out.print("Entrez l'index de l'ordinateur à changer : ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index >= 0 && index < computers.size()) {
            System.out.print("Entrez le nouveau nom : ");
            String newName = scanner.nextLine();
            computers.get(index).setName(newName);
            System.out.println("Nom mis à jour : " + computers.get(index));
        } else {
            System.out.println("Index invalide.");
        }
    }

    private static void addComputer(Scanner scanner) {
        System.out.print("Entrez le nom de l'ordinateur : ");
        String name = scanner.nextLine();
        Keyboard keyboard = new Keyboard();
        Mouse mouse = new Mouse();
        Computer computer = new Computer(name, keyboard, mouse);
        computers.add(computer);
        System.out.println("Ordinateur ajouté : " + computer);
    }

    private static void deleteComputer(Scanner scanner) {
        System.out.print("Entrez l'index de l'ordinateur à supprimer : ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index >= 0 && index < computers.size()) {
            Computer removed = computers.remove(index);
            System.out.println("Ordinateur supprimé : " + removed);
        } else {
            System.out.println("Index invalide.");
        }
    }
}
