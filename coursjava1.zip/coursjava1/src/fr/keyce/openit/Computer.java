package fr.keyce.openit;

public class Computer {
    private String name;
    private Keyboard keyboard;
    private Mouse mouse;

    // Constructeur
    public Computer(String name, Keyboard keyboard, Mouse mouse) {
        this.name = name;
        this.keyboard = keyboard;
        this.mouse = mouse;
    }

    // Getters et Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Keyboard getKeyboard() {
        return keyboard;
    }

    public Mouse getMouse() {
        return mouse;
    }

    // Méthode toString modifiée
    @Override
    public String toString() {
        return "Computer : [name=" + name + "]";
    }
}
