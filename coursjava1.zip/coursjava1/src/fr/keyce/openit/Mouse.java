package fr.keyce.openit;

public class Mouse {
    @Override
    public String toString() {
        return "Mouse";
    }
}
