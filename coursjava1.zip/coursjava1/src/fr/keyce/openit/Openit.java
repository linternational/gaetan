package fr.keyce.openit;

public class Openit {

    public static void main(String[] args) {
        Keyboard keyboard = new Keyboard();
        Mouse mouse = new Mouse();
        Computer computer = new Computer("Dell", keyboard, mouse);
        AppleComputer appleComputer = new AppleComputer("MacBook", keyboard, mouse);

        System.out.println(computer);
        System.out.println(appleComputer);
    }
}
