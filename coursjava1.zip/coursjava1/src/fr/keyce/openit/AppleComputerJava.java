package fr.keyce.openit;

public class AppleComputer extends Computer {

    public AppleComputer(String name, Keyboard keyboard, Mouse mouse) {
        super(name, keyboard, mouse);
    }
}
