package fr.keyce;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            
		JFrame frame= new JFrame("Ma Premiere Fenetre Swing");
		frame.setSize(400,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JButton buttonAddComputer=new JButton("ajouter un ordinateur");
		JButton buttonDelComputer=new JButton("supprimer un ordinateur");
		JButton buttonModifyComputer=new JButton("modifier un ordinateur");
		frame.setLayout(new GridLayout(10,1));
		frame.add(buttonAddComputer);
		frame.add(buttonDelComputer);
		frame.add(buttonModifyComputer);
		frame.setVisible(true);
	}

}
