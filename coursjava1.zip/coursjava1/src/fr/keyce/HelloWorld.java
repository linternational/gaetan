package fr.keyce;

import java.util.Scanner;

public class HelloWorld {

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Veuillez fournir un nom et un âge en paramètres.");
            return;
        }

        Person person = new Person(args[0], Integer.valueOf(args[1]));
        
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n******** MENU ********");
                System.out.println("1. Afficher un ordinateur");
                System.out.println("2. Changer le nom de l'ordinateur");
                System.out.println("3. Ajouter un ordinateur");
                System.out.println("4. supprimer l'ordinateur");
                System.out.print("Choisissez une option : ");
                
                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        System.out.println("Personne actuelle : " + person);
                        break;
                    case 2:
                        System.out.print("Entrez le nouveau nom : ");
                        String newName = scanner.nextLine();
                        person.setName(newName);
                        System.out.println("Nom mis à jour : " + person);
                        break;
                    case 3:
                        person.incrementAge();
                        System.out.println("Un an a été ajouté : " + person);
                        break;
                    case 4:
                        System.out.println("AU REVOIR");
                        return;
                    default:
                        System.out.println("Option invalide, veuillez réessayer.");
                        break;
                }
            }
        }
    }
    
    Computer computer =new Computer(new );
    computer.getMouse();

    private static void switchDay(String day) {
        switch (day.toLowerCase()) {
            case "monday":
                System.out.println("Lundi");
                break;
            case "tuesday":
                System.out.println("Mardi");
                break;
            case "wednesday":
                System.out.println("Mercredi");
                break;
            default:
                System.out.println("Jour inconnu");
                break;
        }
    }
}
